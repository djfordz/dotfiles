# Description of issue

Your description here!

If your bug is not related to highlighting or folding, please feel free
to delete the text below.

# Screenshot of the issue:

![Screenshot](...)

# Sample code:

```perl
```

# Link to vimrc

[vimrc](...)

# Output of `vim --version`
