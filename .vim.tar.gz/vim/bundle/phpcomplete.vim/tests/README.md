## Running the tests
You can run the test suite with the `./runtests.sh` script.
Tests are using the [vimunit plugin](https://github.com/dsummersl/vimunit) if you don't have
it next to your phpcomplete.vim the script will try to get it with git. Running all the tests
you simply enter the tests/ directory and start the script:

    cd ~/.vim/bundle/phpcomplete.vim/tests
    ./runtests.sh
    
