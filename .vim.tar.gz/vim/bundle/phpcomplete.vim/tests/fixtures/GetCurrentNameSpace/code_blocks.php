<?php

use SomeParentNS\SomeChildNS;

$testFunc = function () {
	foreach([] as $a) {
		$test = new SomeChildNS\SomeClass();
		$test->
	}
};
