<?php
NAMESPACE Mahou;
USE DateTime AS DT;

class Foo {

}

$some = method_calls();
