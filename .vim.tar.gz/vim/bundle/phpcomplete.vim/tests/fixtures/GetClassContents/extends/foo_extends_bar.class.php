<?php

class FooClass extends BarClass { }
