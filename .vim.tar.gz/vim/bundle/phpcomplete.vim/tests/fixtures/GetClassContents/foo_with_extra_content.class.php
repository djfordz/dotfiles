<?php
function foo() {
    // code
}

class FooClass {
    public function bar( $baz = 'foo') {
    }
}

function bar() {
    // code
}
