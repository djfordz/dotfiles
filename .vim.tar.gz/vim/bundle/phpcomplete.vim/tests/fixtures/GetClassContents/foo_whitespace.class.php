<?php
class FooClassNotThisOne {
}

class FooClass
{
    public function bar( $baz = 'foo')
    {
    }
}

