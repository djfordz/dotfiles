<?php

class FooPropertiesClass {
    var $property1 = 'foo';
    public $property2 = 'bar';
    public static $static_property = 'bar';
}

