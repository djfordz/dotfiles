<?php

class Foo extends FooBase {

    public function bar() {
        parent::
    }
}
