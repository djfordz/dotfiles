<?php

$foo = new FooClass;
$foo->


$foo2 = new RenamedFoo;
$foo2->


$foo3 = new \NS2\Foo;
$foo3->
