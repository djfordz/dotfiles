<?php

$c = new DateTime;
$d = clone $c;
$d->
