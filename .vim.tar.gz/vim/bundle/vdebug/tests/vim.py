
class MockVim:
    pass
