Version 0.5.1
-------------

* work with phpctags v0.5.1

Version 0.5
-----------

* work with phpctags v0.5

Version 0.4.2
-------------

* work with phpctags v0.4.2

Version 0.4.1
-------------

* work with phpctags v0.4.1

Version 0.4
-----------

* work with phpctags v0.4
* use Makefile to ease the building process
* distributed archive now contains a phpctags executable

Version 0.3
-----------

* work with phpctags v0.3
* able to control the memory size to be used by phpctags
  thanks to Dannel Jurado
* fold functions and methods by default, constants, variables
  and properties are not displayed in the statusline.
  thanks to Chronial

Version 0.2
-----------

* accept general ctags flags
* new kind identifier for method and property

Version 0.1
-----------

* custmizable phpctgas location
* support scope and sccess information
* support variable, function, class, interface
