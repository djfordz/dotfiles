<?php

/**
 * DocBlockedFoo
 *
 * @property DateTime $docBlockFoo
 */
class DocBlockedFoo {

}
