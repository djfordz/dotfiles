<?php

interface Foo {
}

interface Foo2 {
}

interface FooFoo2 extends Foo, Foo2 {
}
