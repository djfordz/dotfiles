<?php

$d = DateTime::createFromFormat();
$d->

$d = DT::createFromFormat();
$d->
